import React from 'react';
class Electronics extends React.Component{

    render(){
    return(
    <React.Fragment>
      <div>
         <h1>"Mansi"</h1>
      </div> 
      <div>
          <h2>"Dhingra"</h2>
      </div> 
    </React.Fragment>
        
    )
    }
    
}
export default Electronics;