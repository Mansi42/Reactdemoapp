



function Home(){
    return (
        <div> 
             <h1 style={
                 {color: "burlywood",
                 textAlign:"center"
                }
                 }>Welcome to HOME PAGE :)</h1>
        </div>
    );
}



export default Home;